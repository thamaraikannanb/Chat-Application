# GoChat
GoChat is a real time chatting web app written in Go and Gin.

Hosted at: https://go-chatters.herokuapp.com
